using System.Text.Json.Serialization;
using Proton.Drive.Sdk.Api.Links;
using Proton.Sdk.Cryptography;

namespace Proton.Drive.Sdk.Api.Files;

internal sealed class FileCreationRequest : NodeCreationRequest
{
    [JsonPropertyName("MIMEType")]
    public required string MediaType { get; init; }

    public required ReadOnlyMemory<byte> ContentKeyPacket { get; init; }

    [JsonPropertyName("ContentKeyPacketSignature")]
    public required PgpArmoredSignature ContentKeySignature { get; init; }

    [JsonPropertyName("ClientUID")]
    public string? ClientUid { get; init; }

    public long? IntendedUploadSize { get; init; }

    [JsonPropertyName("SignatureAddress")]
    public required string SignatureEmailAddress { get; init; }
}
