using Proton.Drive.Sdk.Api.Links;
using Proton.Drive.Sdk.Api.Volumes;
using Proton.Drive.Sdk.Serialization;
using Proton.Drive.Sdk.Volumes;
using Proton.Sdk.Api;
using Proton.Sdk.Api.Http;

namespace Proton.Drive.Sdk.Api.Files;

internal sealed class TrashApiClient(HttpClient httpClient) : ITrashApiClient
{
    private readonly HttpClient _httpClient = httpClient;

    public async ValueTask<VolumeTrashResponse> GetTrashAsync(VolumeId volumeId, int pageSize, int pageIndex, CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.VolumeTrashResponse)
            .GetAsync($"volumes/{volumeId}/trash?pageSize={pageSize}&page={pageIndex}", cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<AggregateApiResponse<LinkIdResponsePair<ApiResponse>>> TrashMultipleAsync(
        VolumeId volumeId,
        MultipleLinksNullaryRequest request,
        CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.AggregateApiResponseLinkIdResponsePairApiResponse)
            .PostAsync($"v2/volumes/{volumeId}/trash_multiple", request, DriveApiSerializerContext.Default.MultipleLinksNullaryRequest, cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask<AggregateApiResponse<LinkIdResponsePair<ApiResponse>>> DeleteMultipleAsync(
        VolumeId volumeId,
        MultipleLinksNullaryRequest request,
        CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.AggregateApiResponseLinkIdResponsePairApiResponse)
            .PostAsync(
                $"v2/volumes/{volumeId}/trash/delete_multiple",
                request,
                DriveApiSerializerContext.Default.MultipleLinksNullaryRequest,
                cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask<AggregateApiResponse<LinkIdResponsePair<ApiResponse>>> RestoreMultipleAsync(
        VolumeId volumeId,
        MultipleLinksNullaryRequest request,
        CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.AggregateApiResponseLinkIdResponsePairApiResponse)
            .PutAsync(
                $"v2/volumes/{volumeId}/trash/restore_multiple",
                request,
                DriveApiSerializerContext.Default.MultipleLinksNullaryRequest,
                cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask<ApiResponse> EmptyAsync(VolumeId volumeId, CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting<ApiResponse>(DriveApiSerializerContext.Default.ApiResponse)
            .DeleteAsync($"volumes/{volumeId}/trash", cancellationToken).ConfigureAwait(false);
    }
}
