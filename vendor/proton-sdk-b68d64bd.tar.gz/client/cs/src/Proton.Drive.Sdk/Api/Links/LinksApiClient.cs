using Proton.Drive.Sdk.Api.Files;
using Proton.Drive.Sdk.Serialization;
using Proton.Drive.Sdk.Volumes;
using Proton.Sdk.Api;
using Proton.Sdk.Api.Http;

namespace Proton.Drive.Sdk.Api.Links;

internal sealed class LinksApiClient(HttpClient httpClient) : ILinksApiClient
{
    private readonly HttpClient _httpClient = httpClient;

    public async ValueTask<LinkDetailsResponse> GetDetailsAsync(VolumeId volumeId, IEnumerable<LinkId> linkIds, CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.LinkDetailsResponse)
            .PostAsync($"v2/volumes/{volumeId}/links", new LinkDetailsRequest(linkIds), DriveApiSerializerContext.Default.LinkDetailsRequest, cancellationToken)
            .ConfigureAwait(false);
    }

    // FIXME use recursive lookup instead, remove this
    public async ValueTask<ContextShareResponse> GetContextShareAsync(VolumeId volumeId, LinkId linkId, CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.ContextShareResponse)
            .GetAsync($"volumes/{volumeId}/links/{linkId}/context", cancellationToken).ConfigureAwait(false);
    }

    public async ValueTask<AggregateApiResponse<LinkIdResponsePair<DetailedApiResponse>>> MoveMultipleAsync(
        VolumeId volumeId,
        MoveMultipleLinksRequest request,
        CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.AggregateApiResponseLinkIdResponsePairDetailedApiResponse)
            .PutAsync($"volumes/{volumeId}/links/move-multiple", request, DriveApiSerializerContext.Default.MoveMultipleLinksRequest, cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask<ApiResponse> RenameAsync(VolumeId volumeId, LinkId linkId, RenameLinkRequest request, CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting<ApiResponse>(DriveApiSerializerContext.Default.ApiResponse)
            .PutAsync($"v2/volumes/{volumeId}/links/{linkId}/rename", request, DriveApiSerializerContext.Default.RenameLinkRequest, cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask<AggregateApiResponse<LinkIdResponsePair<ApiResponse>>> DeleteMultipleAsync(
        VolumeId volumeId,
        IEnumerable<LinkId> linkIds,
        CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.AggregateApiResponseLinkIdResponsePairApiResponse)
            .PostAsync(
                $"v2/volumes/{volumeId}/delete_multiple",
                new MultipleLinksNullaryRequest { LinkIds = linkIds },
                DriveApiSerializerContext.Default.MultipleLinksNullaryRequest,
                cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask<NodeNameAvailabilityResponse> GetAvailableNames(
        VolumeId volumeId,
        LinkId folderId,
        NodeNameAvailabilityRequest request,
        CancellationToken cancellationToken)
    {
        return await _httpClient
            .Expecting(DriveApiSerializerContext.Default.NodeNameAvailabilityResponse)
            .PostAsync(
                $"v2/volumes/{volumeId}/links/{folderId}/checkAvailableHashes",
                request,
                DriveApiSerializerContext.Default.NodeNameAvailabilityRequest,
                cancellationToken)
            .ConfigureAwait(false);
    }

    public async ValueTask ReportRecentlyAccessedAsync(ReportRecentlyAccessedItemsRequest request, CancellationToken cancellationToken)
    {
        await _httpClient
            .Expecting(DriveApiSerializerContext.Default.ApiResponse)
            .PostAsync("recently-accessed-items", request, DriveApiSerializerContext.Default.ReportRecentlyAccessedItemsRequest, cancellationToken)
            .ConfigureAwait(false);
    }
}
