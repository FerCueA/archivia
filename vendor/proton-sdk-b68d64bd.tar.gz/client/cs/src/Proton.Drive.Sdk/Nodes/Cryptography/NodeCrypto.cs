using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Proton.Cryptography.Pgp;
using Proton.Drive.Sdk.Api.Files;
using Proton.Drive.Sdk.Api.Links;
using Proton.Drive.Sdk.Serialization;
using Proton.Sdk;
using Proton.Sdk.Cryptography;
using Proton.Sdk.Serialization;

namespace Proton.Drive.Sdk.Nodes.Cryptography;

internal static class NodeCrypto
{
    private const string SharingInviterSigningContext = "drive.share-member.inviter";

    public static async ValueTask<FolderDecryptionResult> DecryptFolderAsync(
        IProtonAccountClient accountClient,
        LinkDto link,
        PgpArmoredMessage folderHashKey,
        PgpPrivateKey parentKey,
        CancellationToken cancellationToken)
    {
        var linkDecryptionResult = await DecryptLinkAsync(accountClient, link, parentKey, cancellationToken).ConfigureAwait(false);

        var hashKeyResult = DecryptHashKey(folderHashKey, linkDecryptionResult.NodeKey, linkDecryptionResult.NodeAuthorshipClaim);

        return new FolderDecryptionResult
        {
            Link = linkDecryptionResult,
            HashKey = hashKeyResult,
        };
    }

    public static async ValueTask<FileDecryptionResult> DecryptFileAsync(
        IProtonAccountClient accountClient,
        LinkDto linkDto,
        FileDto fileDto,
        ActiveRevisionDto activeRevisionDto,
        PgpPrivateKey parentKey,
        CancellationToken cancellationToken)
    {
        var contentAuthorshipClaim =
            await AuthorshipClaim.CreateAsync(accountClient, activeRevisionDto.SignatureEmailAddress, cancellationToken).ConfigureAwait(false);

        var linkDecryptionResult = await DecryptLinkAsync(accountClient, linkDto, parentKey, cancellationToken).ConfigureAwait(false);

        var contentKeyDecryptionResult = DecryptContentKey(
            linkDecryptionResult.NodeKey,
            fileDto.ContentKeyPacket,
            fileDto.ContentKeySignature,
            linkDecryptionResult.NodeAuthorshipClaim);

        var extendedAttributesResult = DecryptExtendedAttributes(
            activeRevisionDto.ExtendedAttributes,
            linkDecryptionResult.NodeKey,
            contentAuthorshipClaim);

        return new FileDecryptionResult
        {
            Link = linkDecryptionResult,
            ContentKey = contentKeyDecryptionResult,
            ExtendedAttributes = extendedAttributesResult,
            ContentAuthorshipClaim = contentAuthorshipClaim,
        };
    }

    public static byte[] HashNodeName(string name, ReadOnlySpan<byte> parentFolderHashKey)
    {
        var maxNameByteLength = Encoding.UTF8.GetMaxByteCount(name.Length);
        var nameBytes = MemoryPolicy.GetRentedHeapMemoryIfTooLargeForStack<byte>(maxNameByteLength, out var nameHeapMemoryOwner)
            ? nameHeapMemoryOwner.Memory.Span
            : stackalloc byte[maxNameByteLength];

        using (nameHeapMemoryOwner)
        {
            var nameByteLength = Encoding.UTF8.GetBytes(name, nameBytes);
            nameBytes = nameBytes[..nameByteLength];

            return HMACSHA256.HashData(parentFolderHashKey, nameBytes);
        }
    }

    public static byte[] HashContentDigest(ReadOnlyMemory<byte> contentDigest, ReadOnlySpan<byte> parentFolderHashKey)
    {
        Span<byte> hexBuffer = stackalloc byte[contentDigest.Length * 2];

        var hexString = contentDigest.Span.ToHexStringLower(hexBuffer);

        return HMACSHA256.HashData(parentFolderHashKey, hexString);
    }

    /// <summary>
    /// Verifies the inviter's signature over the membership share-passphrase key packet.
    /// Returns <see langword="null"/> when the signature is valid, or an
    /// <see cref="AuthorshipVerificationFailure"/> describing why it could not be verified.
    /// </summary>
    public static AuthorshipVerificationFailure? VerifyMembershipInviter(
        ReadOnlyMemory<byte>? keyPacket,
        PgpArmoredSignature? keyPacketSignature,
        AuthorshipClaim inviterClaim)
    {
        if (keyPacket is not { } packet || keyPacketSignature is not { } signature)
        {
            // The invitation carries no signature to verify against.
            return new AuthorshipVerificationFailure(PgpVerificationStatus.NotSigned);
        }

        if (inviterClaim.Author == Author.Anonymous || inviterClaim.Keys is not { Count: > 0 })
        {
            // No inviter identity or no keys available to verify with.
            return new AuthorshipVerificationFailure(PgpVerificationStatus.NoVerifier);
        }

        try
        {
            using var verificationContext = PgpVerificationContext.Create(SharingInviterSigningContext);

            var verificationStatus = new PgpKeyRing(inviterClaim.Keys)
                .Verify(packet.Span, signature.Unarmored.Span, verificationContext: verificationContext)
                .Status;

            return verificationStatus is not PgpVerificationStatus.Ok
                ? new AuthorshipVerificationFailure(verificationStatus)
                : null;
        }
        catch (Exception e)
        {
            return new AuthorshipVerificationFailure(PgpVerificationStatus.Failed, e.ToProtonDriveError());
        }
    }

    public static Result<DecryptionOutput<ExtendedAttributes?>, ProtonDriveError> DecryptExtendedAttributes(
        PgpArmoredMessage? encryptedExtendedAttributes,
        Result<PgpPrivateKey, ProtonDriveError> nodeKeyResult,
        AuthorshipClaim authorshipClaim)
    {
        if (encryptedExtendedAttributes is null)
        {
            return new DecryptionOutput<ExtendedAttributes?>(null);
        }

        if (!nodeKeyResult.TryGetValueElseError(out var nodeKey, out var error))
        {
            return new ProtonDriveError("Could not unlock the item", error);
        }

        ArraySegment<byte> serializedExtendedAttributes;
        AuthorshipVerificationFailure? authorshipVerificationFailure;
        try
        {
            serializedExtendedAttributes = DecryptMessage(
                encryptedExtendedAttributes.Value,
                detachedSignatureOrNull: null,
                nodeKey,
                authorshipClaim.GetKeyRing(nodeKey),
                out _,
                out authorshipVerificationFailure);
        }
        catch (Exception e)
        {
            return new DecryptionError("Could not unlock item's details", e.ToProtonDriveError());
        }

        try
        {
            var extendedAttributes = JsonSerializer.Deserialize(serializedExtendedAttributes, DriveApiSerializerContext.Default.ExtendedAttributes);

            return new DecryptionOutput<ExtendedAttributes?>(extendedAttributes, authorshipVerificationFailure);
        }
        catch (JsonException e)
        {
            return new ExtendedAttributesDeserializationError(e.ToEnrichedProtonDriveError(serializedExtendedAttributes));
        }
        catch (Exception e)
        {
            return new ProtonDriveError("Could not read item's metadata", e.ToProtonDriveError());
        }
    }

    private static async ValueTask<LinkDecryptionResult> DecryptLinkAsync(
        IProtonAccountClient accountClient,
        LinkDto link,
        PgpPrivateKey parentKey,
        CancellationToken cancellationToken)
    {
        var nodeAuthorshipClaim = await AuthorshipClaim.CreateAsync(accountClient, link.SignatureEmailAddress, cancellationToken).ConfigureAwait(false);

        var nameAuthorshipClaim = link.NameSignatureEmailAddress != link.SignatureEmailAddress
            ? await AuthorshipClaim.CreateAsync(accountClient, link.NameSignatureEmailAddress, cancellationToken).ConfigureAwait(false)
            : nodeAuthorshipClaim;

        var nameResult = DecryptName(link.Name, parentKey, nameAuthorshipClaim);
        var passphraseResult = DecryptPassphrase(parentKey, link.Passphrase, link.PassphraseSignature, nodeAuthorshipClaim);

        var nodeKeyResult = UnlockNodeKey(link.Key, passphraseResult);

        return new LinkDecryptionResult
        {
            Passphrase = passphraseResult,
            NodeAuthorshipClaim = nodeAuthorshipClaim,
            Name = nameResult,
            NameAuthorshipClaim = nameAuthorshipClaim,
            NodeKey = nodeKeyResult,
        };
    }

    private static Result<PhasedDecryptionOutput<ReadOnlyMemory<byte>>, ProtonDriveError> DecryptPassphrase(
        PgpPrivateKey parentNodeKey,
        PgpArmoredMessage encryptedPassphrase,
        PgpArmoredSignature? signature,
        AuthorshipClaim authorshipClaim)
    {
        try
        {
            var passphrase = DecryptMessage(
                encryptedPassphrase,
                signature,
                parentNodeKey,
                authorshipClaim.GetKeyRing(parentNodeKey),
                out var sessionKey,
                out var author);

            return new PhasedDecryptionOutput<ReadOnlyMemory<byte>>(sessionKey, passphrase, author);
        }
        catch (Exception e)
        {
            return new ProtonDriveError("Could not unlock the item", e.ToProtonDriveError());
        }
    }

    private static Result<PgpPrivateKey, ProtonDriveError> UnlockNodeKey(
        PgpSecretKey lockedKey,
        Result<PhasedDecryptionOutput<ReadOnlyMemory<byte>>, ProtonDriveError> passphraseResult)
    {
        if (!passphraseResult.TryGetValueElseError(out var passphrase, out var error))
        {
            return new ProtonDriveError("Could not unlock the item's key", error);
        }

        try
        {
            return lockedKey.Unlock(passphrase.Data.Span);
        }
        catch (Exception e)
        {
            return new ProtonDriveError("Could not unlock the item", e.ToProtonDriveError());
        }
    }

    private static Result<PhasedDecryptionOutput<string>, ProtonDriveError> DecryptName(
        PgpArmoredMessage encryptedName,
        PgpPrivateKey parentNodeKey,
        AuthorshipClaim authorshipClaim)
    {
        try
        {
            var nameUtf8Bytes = DecryptMessage(
                encryptedName,
                detachedSignatureOrNull: null,
                parentNodeKey,
                authorshipClaim.GetKeyRing(parentNodeKey),
                out var sessionKey,
                out var author);

            var name = Encoding.UTF8.GetString(nameUtf8Bytes);

            return new PhasedDecryptionOutput<string>(sessionKey, name, author);
        }
        catch (Exception e)
        {
            return new ProtonDriveError("Failed to decrypt name", e.ToProtonDriveError());
        }
    }

    private static Result<DecryptionOutput<ReadOnlyMemory<byte>>, ProtonDriveError> DecryptHashKey(
        PgpArmoredMessage encryptedHashKey,
        Result<PgpPrivateKey, ProtonDriveError> nodeKeyResult,
        AuthorshipClaim authorshipClaim)
    {
        if (!nodeKeyResult.TryGetValueElseError(out var nodeKey, out var error))
        {
            return new ProtonDriveError("Could not unlock the folder's key", error);
        }

        try
        {
            var verificationKeyRing = GetContentKeyAndHashKeyVerificationKeyRing(nodeKey, authorshipClaim);
            var hashKey = DecryptMessage(encryptedHashKey, detachedSignatureOrNull: null, nodeKey, verificationKeyRing, out _, out var author);
            return new DecryptionOutput<ReadOnlyMemory<byte>>(hashKey, author);
        }
        catch (Exception e)
        {
            return new ProtonDriveError("Could not unlock the folder", e.ToProtonDriveError());
        }
    }

    private static PgpKeyRing GetContentKeyAndHashKeyVerificationKeyRing(PgpPrivateKey nodeKey, AuthorshipClaim authorshipClaim)
    {
        var keys = new List<PgpKey>([nodeKey]);
        if (authorshipClaim.Author != Author.Anonymous)
        {
            keys.AddRange(authorshipClaim.Keys.Select(k => (PgpKey)k));
        }

        return new PgpKeyRing(keys);
    }

    private static Result<DecryptionOutput<PgpSessionKey>, ProtonDriveError> DecryptContentKey(
        Result<PgpPrivateKey, ProtonDriveError> nodeKeyResult,
        ReadOnlyMemory<byte> contentKeyPacket,
        PgpArmoredSignature? contentKeySignatureOrNull,
        AuthorshipClaim nodeAuthorshipClaim)
    {
        if (!nodeKeyResult.TryGetValueElseError(out var nodeKey, out var error))
        {
            return new ProtonDriveError("Could not unlock the file", error);
        }

        PgpSessionKey contentKey;
        try
        {
            contentKey = nodeKey.DecryptSessionKey(contentKeyPacket.Span);
        }
        catch (Exception e)
        {
            return new ProtonDriveError("Could not unlock the file's content", e.ToProtonDriveError());
        }

        var verificationKeyRing = GetContentKeyAndHashKeyVerificationKeyRing(nodeKey, nodeAuthorshipClaim);

        AuthorshipVerificationFailure? verificationFailure;
        try
        {
            var verificationStatus = contentKeySignatureOrNull is { } contentKeySignature
                ? verificationKeyRing.Verify(contentKey.Export(), contentKeySignature.Unarmored.Span).Status
                : PgpVerificationStatus.NotSigned;

            verificationFailure = verificationStatus is not PgpVerificationStatus.Ok
                ? new AuthorshipVerificationFailure(verificationStatus)
                : null;
        }
        catch (Exception e)
        {
            verificationFailure = new AuthorshipVerificationFailure(PgpVerificationStatus.Failed, e.ToProtonDriveError());
        }

        return new DecryptionOutput<PgpSessionKey>(contentKey, verificationFailure);
    }

    private static ArraySegment<byte> DecryptMessage(
        PgpArmoredMessage encryptedMessage,
        PgpArmoredSignature? detachedSignatureOrNull,
        PgpPrivateKey decryptionKey,
        PgpKeyRing verificationKeyRing,
        out PgpSessionKey sessionKey,
        out AuthorshipVerificationFailure? authorshipVerificationFailure)
    {
        sessionKey = decryptionKey.DecryptSessionKey(encryptedMessage.Unarmored.Span);

        var plaintext = detachedSignatureOrNull is { } detachedSignature
            ? sessionKey.DecryptAndVerify(encryptedMessage.Unarmored.Span, detachedSignature.Unarmored.Span, verificationKeyRing, out var verificationResult)
            : sessionKey.DecryptAndVerify(encryptedMessage.Unarmored.Span, verificationKeyRing, out verificationResult);

        authorshipVerificationFailure = verificationResult.Status is not PgpVerificationStatus.Ok
            ? new AuthorshipVerificationFailure(verificationResult.Status)
            : null;

        return plaintext;
    }
}
