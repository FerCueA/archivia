using Proton.Cryptography.Pgp;
using Proton.Drive.Sdk.Api.Files;
using Proton.Sdk;

namespace Proton.Drive.Sdk.Nodes.Cryptography;

internal sealed class FileDecryptionResult
{
    public required LinkDecryptionResult Link { get; init; }
    public required Result<DecryptionOutput<PgpSessionKey>, ProtonDriveError> ContentKey { get; init; }
    public required Result<DecryptionOutput<ExtendedAttributes?>, ProtonDriveError> ExtendedAttributes { get; init; }
    public required AuthorshipClaim ContentAuthorshipClaim { get; init; }
}
