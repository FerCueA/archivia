export { COMMANDS } from './registry';
